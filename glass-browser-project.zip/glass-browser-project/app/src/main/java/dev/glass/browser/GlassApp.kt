package dev.glass.browser

import android.app.Application
import org.mozilla.geckoview.GeckoRuntime

/** Глобальный синглтон GeckoRuntime: на процесс допускается только один экземпляр. */
class GlassApp : Application() {
    lateinit var runtime: GeckoRuntime
        private set

    override fun onCreate() {
        super.onCreate()
        runtime = GeckoRuntime.create(this)
    }
}
