package dev.glass.browser

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

/** Матовая заливка + контурная обводка 1dp (градиент с альфой) — «грани стекла». Работает на любом API. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(28.dp), tint: Color = Color.White): Modifier = this
    .clip(shape)
    .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.26f), tint.copy(alpha = 0.08f))))
    .border(
        1.dp,
        Brush.linearGradient(listOf(Color.White.copy(0.75f), Color.White.copy(0.06f), Color.White.copy(0.40f))),
        shape,
    )

/**
 * Стеклянная панель.
 * API 31+: под контентом лежит слой цветных пятен, размытый RenderEffect.createBlurEffect(),
 *          поверх — матовая заливка и обводка (контент панели НЕ размывается).
 * API < 31: полупрозрачный градиент без блюра (сохраняем 60/120 FPS).
 *
 * Важно: GeckoView — это SurfaceView в отдельной поверхности, Compose не может размыть «то, что за ним».
 * Поэтому стекло здесь имитируется собственным фоном панели, а веб-контент остаётся изолированным и не лагает.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    tint: Color = Color.White,
    content: @Composable () -> Unit,
) {
    Box(modifier.clip(shape)) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Box(
                Modifier
                    .matchParentSize()
                    .graphicsLayer {
                        renderEffect = RenderEffect
                            .createBlurEffect(48f, 48f, Shader.TileMode.DECAL)
                            .asComposeRenderEffect()
                    }
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF7C9CFF).copy(alpha = 0.55f),
                                Color(0xFFB57CFF).copy(alpha = 0.45f),
                                Color(0xFF6EE7D8).copy(alpha = 0.40f),
                            )
                        )
                    )
            )
        } else {
            Box(
                Modifier
                    .matchParentSize()
                    .background(Brush.verticalGradient(listOf(Color(0xCC2A2F45), Color(0xAA1B1F33))))
            )
        }
        Box(Modifier.matchParentSize().glass(shape, tint))
        content()
    }
}
