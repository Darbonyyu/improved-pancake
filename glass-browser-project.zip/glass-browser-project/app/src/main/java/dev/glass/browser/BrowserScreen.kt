package dev.glass.browser

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.focus.onFocusChanged
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

@Composable
fun BrowserScreen(vm: BrowserViewModel = viewModel()) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeId by vm.activeId.collectAsStateWithLifecycle()
    val tab = tabs.firstOrNull { it.id == activeId } ?: return
    var showTabs by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color(0xFF0E1020))) {
        // Веб-контент изолирован от стеклянных оверлеев
        GeckoHost(tab.session, Modifier.fillMaxSize())

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            AnimatedVisibility(showTabs) {
                TabSheet(
                    tabs, activeId,
                    onSelect = { vm.selectTab(it); showTabs = false },
                    onClose = vm::closeTab,
                    onNew = { vm.newTab(); showTabs = false },
                    onNewPrivate = { vm.newTab(isPrivate = true); showTabs = false },
                )
            }
            BottomBar(tab, tabs.size, vm, onTabs = { showTabs = !showTabs })
        }
    }
}

@Composable
private fun GeckoHost(session: GeckoSession, modifier: Modifier) {
    val ctx = LocalContext.current
    val view = remember { GeckoView(ctx) }
    AndroidView(
        factory = { view },
        modifier = modifier,
        update = { if (it.session !== session) it.setSession(session) },
    )
    DisposableEffect(view) { onDispose { view.releaseSession() } }
}

@Composable
private fun BottomBar(tab: TabState, count: Int, vm: BrowserViewModel, onTabs: () -> Unit) {
    var text by remember(tab.id) { mutableStateOf(tab.url) }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(tab.url, tab.id) { if (!focused) text = tab.url }
    val tint = if (tab.isPrivate) Color(0xFFB57CFF) else Color.White

    GlassSurface(Modifier.fillMaxWidth(), tint = tint) {
        Column {
            if (tab.progress in 1..99) {
                LinearProgressIndicator(
                    progress = { tab.progress / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = Color.White, trackColor = Color.Transparent,
                )
            }
            Row(
                Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = vm::back, enabled = tab.canBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = Color.White.copy(if (tab.canBack) 1f else .35f))
                }
                IconButton(onClick = vm::forward, enabled = tab.canForward) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, "Вперёд", tint = Color.White.copy(if (tab.canForward) 1f else .35f))
                }
                Row(
                    Modifier.weight(1f).height(40.dp).glass(RoundedCornerShape(20.dp)).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (tab.secure) Icon(Icons.Filled.Lock, "HTTPS", tint = Color(0xFF7CFFB2), modifier = Modifier.size(14.dp).padding(end = 0.dp))
                    Spacer(Modifier.width(6.dp))
                    BasicTextField(
                        value = text, onValueChange = { text = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(Color.White),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { vm.load(text) }),
                        modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
                    )
                }
                IconButton(onClick = vm::reload) { Icon(Icons.Filled.Refresh, "Обновить", tint = Color.White) }
                Box(
                    Modifier.size(32.dp).glass(RoundedCornerShape(10.dp)).clickable(onClick = onTabs),
                    contentAlignment = Alignment.Center,
                ) { Text("$count", color = Color.White, fontSize = 13.sp) }
                Spacer(Modifier.width(4.dp))
            }
        }
    }
}

@Composable
private fun TabSheet(
    tabs: List<TabState>, activeId: Int,
    onSelect: (Int) -> Unit, onClose: (Int) -> Unit,
    onNew: () -> Unit, onNewPrivate: () -> Unit,
) {
    GlassSurface(Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Вкладка", onNew)
                Pill("Приватная", onNewPrivate, Color(0xFFB57CFF))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(tabs, key = { it.id }) { t ->
                    Row(
                        Modifier.fillMaxWidth()
                            .glass(RoundedCornerShape(16.dp), if (t.isPrivate) Color(0xFFB57CFF) else Color.White)
                            .background(if (t.id == activeId) Color.White.copy(0.12f) else Color.Transparent)
                            .clickable { onSelect(t.id) }
                            .padding(start = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            t.title.ifBlank { t.url.ifBlank { "Новая вкладка" } },
                            color = Color.White, fontSize = 14.sp, maxLines = 1,
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { onClose(t.id) }) { Icon(Icons.Filled.Close, "Закрыть", tint = Color.White) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Pill(label: String, onClick: () -> Unit, tint: Color = Color.White) {
    Row(
        Modifier.glass(RoundedCornerShape(18.dp), tint).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}
