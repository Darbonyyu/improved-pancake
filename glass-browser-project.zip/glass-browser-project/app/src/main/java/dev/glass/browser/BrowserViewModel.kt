package dev.glass.browser

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings

data class TabState(
    val id: Int,
    val session: GeckoSession,
    val isPrivate: Boolean,
    val url: String = "",
    val title: String = "",
    val canBack: Boolean = false,
    val canForward: Boolean = false,
    val progress: Int = 0,
    val secure: Boolean = false,
)

/** Менеджер вкладок: каждая вкладка = отдельная GeckoSession (приватная — usePrivateMode). */
class BrowserViewModel(app: Application) : AndroidViewModel(app) {
    private val runtime = (app as GlassApp).runtime
    private var nextId = 1

    private val _tabs = MutableStateFlow<List<TabState>>(emptyList())
    val tabs: StateFlow<List<TabState>> = _tabs.asStateFlow()

    private val _activeId = MutableStateFlow(-1)
    val activeId: StateFlow<Int> = _activeId.asStateFlow()

    init { newTab() }

    private fun update(id: Int, f: (TabState) -> TabState) =
        _tabs.update { list -> list.map { if (it.id == id) f(it) else it } }

    fun newTab(isPrivate: Boolean = false, url: String = HOME) {
        val id = nextId++
        val settings = GeckoSessionSettings.Builder().usePrivateMode(isPrivate).build()
        val session = GeckoSession(settings)

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) = update(id) { it.copy(progress = 5) }
            override fun onProgressChange(session: GeckoSession, progress: Int) = update(id) { it.copy(progress = progress) }
            override fun onPageStop(session: GeckoSession, success: Boolean) = update(id) { it.copy(progress = 100) }
            override fun onSecurityChange(
                session: GeckoSession,
                securityInfo: GeckoSession.ProgressDelegate.SecurityInformation,
            ) = update(id) { it.copy(secure = securityInfo.isSecure) }
        }
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean,
            ) = update(id) { it.copy(url = url.orEmpty()) }
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) = update(id) { it.copy(canBack = canGoBack) }
            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) = update(id) { it.copy(canForward = canGoForward) }
        }
        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) = update(id) { it.copy(title = title.orEmpty()) }
        }

        session.open(runtime)
        session.loadUri(url)
        _tabs.update { it + TabState(id, session, isPrivate, url = url) }
        _activeId.value = id
    }

    fun selectTab(id: Int) { _activeId.value = id }

    fun closeTab(id: Int) {
        val list = _tabs.value
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        list[idx].session.close()
        val rest = list.filterNot { it.id == id }
        _tabs.value = rest
        if (rest.isEmpty()) newTab()
        else if (_activeId.value == id) _activeId.value = rest[(idx - 1).coerceAtLeast(0)].id
    }

    private fun active(): TabState? = _tabs.value.firstOrNull { it.id == _activeId.value }

    fun back() = active()?.session?.goBack()
    fun forward() = active()?.session?.goForward()
    fun reload() = active()?.session?.reload()
    fun load(input: String) { active()?.session?.loadUri(normalize(input)) }

    private fun normalize(raw: String): String {
        val s = raw.trim()
        return when {
            s.startsWith("http://") || s.startsWith("https://") || s.startsWith("about:") -> s
            !s.contains(' ') && s.contains('.') -> "https://$s"
            else -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(s, "UTF-8")
        }
    }

    override fun onCleared() { _tabs.value.forEach { it.session.close() } }

    companion object { const val HOME = "https://start.duckduckgo.com" }
}
