# Glass Browser
Kotlin + Compose + GeckoView, стиль Glassmorphism, адресная строка внизу.
Сборка: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
Требуется JDK 17, ANDROID_HOME, `sdkmanager --licenses`.
